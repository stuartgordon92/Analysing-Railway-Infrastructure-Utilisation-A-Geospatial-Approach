
import json
import base64
import boto3
import os
import time
import uuid
import datetime
import xmltodict
import re


def is_json(myjson):
    try:
        json.loads(myjson)
    except ValueError as e:
        return False
    return True

namespaces = {
	 "http://www.thalesgroup.com/rtti/PushPort/v16": None,
	 "http://www.thalesgroup.com/rtti/PushPort/Schedules/v3": None,
	 "http://www.thalesgroup.com/rtti/PushPort/Schedules/v2": None,
	 "http://www.thalesgroup.com/rtti/PushPort/Formations/v2": None, 
	 "http://www.thalesgroup.com/rtti/PushPort/Forecasts/v3": None,
	 "http://www.thalesgroup.com/rtti/PushPort/Formations/v1": None,
	 "http://www.thalesgroup.com/rtti/PushPort/StationMessages/v1": None,
	 "http://www.thalesgroup.com/rtti/PushPort/TrainAlerts/v1": None,
	 "http://www.thalesgroup.com/rtti/PushPort/TrainOrder/v1": None,
     "http://www.thalesgroup.com/rtti/PushPort/TDData/v1": None,
	 "http://www.thalesgroup.com/rtti/PushPort/Alarms/v1": None,
	 "http://thalesgroup.com/RTTI/PushPortStatus/root_1": None
}

S3_BUCKET=os.getenv('s3Bucket')
S3_BUCKET_FOLDER=os.getenv('s3BucketFolder')

s3 = boto3.client('s3')

td_queue = "TEST.NROD.TD_ALL_SIG_AREA::rail"

def strip_td_msg(td_msg):
    updated_td = []
    for msg in td_msg:
        msg_type = str(next(iter(msg)))
        updated_td.append(msg[msg_type])
    return updated_td


def xml_to_json(xml):
    message = json.dumps(xmltodict.parse(xml, process_namespaces=True, namespaces=namespaces))
    message = re.sub('[@#]','', message)
    return message

def put_s3_object(content, queues, message_format):
    date_time = datetime.datetime.now()
    date_timestamp = date_time.strftime("%Y%m%d_%H%M%S_%f")
    file_name = '/'.join([f"{queues}", f"date={date_time.year}{date_time.month:02d}{date_time.day:02d}", f"{str(uuid.uuid4())}"])
    full_file_name = S3_BUCKET_FOLDER + "/" + file_name + '.' + message_format
    multiline_string = '\r\n'.join(content)
    s3.put_object(Body=multiline_string,Key=full_file_name,Bucket=S3_BUCKET)

def lambda_handler(event, context):
    for queues in event['rmqMessagesByQueue']:
        print (f"Queue: {queues}")
        messages = []
        for message in event['rmqMessagesByQueue'][queues]:
            data = base64.b64decode(message['data']).decode('ascii')
            if is_json(data):
                data = json.loads(data)
                if queues == td_queue:
                    data = strip_td_msg(data)
                if len(data) >= 1:
                    for msg in data:
                        messages.append(json.dumps(msg))
                else:
                    messages.append(json.dumps(data))
                format = "json"
            else:
                data = xml_to_json(data)
                messages.append(data)
                format = "xml"

        print (f"Decoded messages in {queues} - {len(messages)}")
        put_s3_object(messages ,queues, "json")