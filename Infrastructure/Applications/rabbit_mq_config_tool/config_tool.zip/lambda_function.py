import json
import urllib3
import os
import datetime
import boto3
import uuid
from io import BytesIO

RABBIT_USER=os.getenv('rabbitUser')
RABBIT_PASS=os.getenv('rabbitPass')
RABBIT_DEF_S3_KEY=os.getenv('rabbitDefS3Key')
CONFIG_BUCKET=os.getenv('configBucket')
RABBIT_BROKER=os.getenv('rabbitBroker')

s3 = boto3.client('s3')

url = f'{RABBIT_BROKER}/api/definitions'

def get_rabbit_def_from_s3(bucket, s3_key):
    response = s3.get_object(Bucket=bucket, Key=s3_key)
    return response['Body'].read().decode('utf-8')

def lambda_handler(event, context):
    print(f"Attempting to update Rabbit MQ Broker with saved config")
    print(f"Retriving config from {CONFIG_BUCKET}/{RABBIT_DEF_S3_KEY}")
    def_file = get_rabbit_def_from_s3(CONFIG_BUCKET, RABBIT_DEF_S3_KEY)
    print(f"Rabbit Configuration file: {def_file}")
    
    http = urllib3.PoolManager()
    headers = urllib3.make_headers(basic_auth=f"{RABBIT_USER}:{RABBIT_PASS}")
    content = {'Content-Type': 'application/json'}
    resp = http.request('POST', url, headers=(headers|content), body=def_file)
    print("Request sent")
    if resp.status == 204:
        print(f"{resp.status} - Update should have been successful")
    else:
        print("Error probably occured - review file and broker")
        print(resp.info())

    
