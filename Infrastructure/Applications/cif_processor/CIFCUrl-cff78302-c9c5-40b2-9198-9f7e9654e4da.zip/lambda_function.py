import json
import urllib3
import os
import datetime
import boto3
import uuid

STOMP_USER=os.getenv('stompUser')
STOMP_PASS=os.getenv('stompPass')
S3_BUCKET=os.getenv('s3Bucket')
S3_BUCKET_FOLDER=os.getenv('s3BucketFolder')
CIF_INSTANCE=os.getenv('instance')


s3 = boto3.client('s3')
ec2 = boto3.resource('ec2')
url = 'https://publicdatafeeds.networkrail.co.uk/ntrod/CifFileAuthenticate?type=CIF_ALL_FULL_DAILY&day=toc-full'


def put_s3_object(message):
    queues = 'CIF_ALL_FULL_DAILY'
    date_time = datetime.datetime.now()
    date_timestamp = date_time.strftime("%Y%m%d_%H%M%S_%f")
    file_name = '/'.join([f"{queues}", f"date={date_time.year}{date_time.month:02d}{date_time.day:02d}", f"toc_full_daily_cif_{date_time.year}{date_time.month:02d}{date_time.day:02d}"])
    json_file_name = S3_BUCKET_FOLDER + "/" + file_name + '.gz'
    print(f"Message Saved: {json_file_name}")

    s3.put_object(Body=message.data,Key=json_file_name,Bucket=S3_BUCKET)
    print('Pushed file to S3')


def lambda_handler(event, context):
    http = urllib3.PoolManager()
    headers = urllib3.make_headers(basic_auth=f"{STOMP_USER}:{STOMP_PASS}")
    resp = http.request('GET', url, headers=headers)
    
    print(resp.info())
    print(resp.status)
    
    put_s3_object(resp)

    print(f"Stopping instance - {CIF_INSTANCE}")
    ec2.Instance(CIF_INSTANCE).start()